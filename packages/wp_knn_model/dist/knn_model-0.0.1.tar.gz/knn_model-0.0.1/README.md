=> Water permeability prediction model

- Description:
k nearest neighbors regression model for prediction of the water permeability
level of forest soil. The model is intended to be use in the forest industry to
guide routing decisions in harvesting operations.

The soil water permeability 𝑥𝑤𝑝 can be used as an indicator for the bearing capacity of the soil, 
which is a crucially important factor in harvest operations with heavy machinery.
The predicted value of 𝑥𝑤𝑝 will be used to guide routing decisions in order to minimize risks 
for the forest harvester.
A route consists from a fixed number of spatially distributed points, for all of which we need
 a prediction on the 𝑥𝑤𝑝 level, in order to evaluate the route’s goodness.
 

# TODO: 
	Add this only to the readme of the API:

 	The prediction system should be an online system, that is, the predictions should be made on-site
 	from the harvester’s current geographical position.

# TODO: 
	Instrucctions:
	
	# Just clone or download the repository and run "REST-API-3.0/requirements.txt"
	> pip install -r path/to/directory/REST-API-3.0/requirements.txt

	# The flask app is located on: REST-API-3.0/packages/ml_api/api/application.py


	# To install only the regression_model package locally:
	>pip install -e \path\to\package\REST-API-3.0\packages\regression_model

	# To install only the regression_model package from github:
	>pip install git+git://github.com/JoaquinRives/regression-package-V3
	



